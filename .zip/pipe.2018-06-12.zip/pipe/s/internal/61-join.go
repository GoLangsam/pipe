// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pipe

// ===========================================================================
// Beg of JoinAny fan-in's

// JoinAny returns a channel to receive
// everything from the given original channel `ori`
// as well as
// all inputs
// before close.
func JoinAny(ori <-chan Any, inp ...Any) (out <-chan Any) {
	return FanIn2Any(ori, ChanAny(inp...))
}

// JoinAnySlice returns a channel to receive
// everything from the given original channel `ori`
// as well as
// all inputs
// before close.
func JoinAnySlice(ori <-chan Any, inp ...[]Any) (out <-chan Any) {
	return FanIn2Any(ori, ChanAnySlice(inp...))
}

// JoinAnyChan returns a channel to receive
// everything from the given original channel `ori`
// as well as
// from the the input channel `inp`
// before close.
//  Note: JoinAnyChan is nothing but FanIn2Any
func JoinAnyChan(ori <-chan Any, inp <-chan Any) (out <-chan Any) {
	return FanIn2Any(ori, inp)
}

// JoinAnyFuncNok returns a channel to receive
// everything from the given original channel `ori`
// as well as
// all results of generator `gen`
// until `!ok`
// before close.
func JoinAnyFuncNok(ori <-chan Any, gen func() (Any, bool)) (out <-chan Any) {
	return FanIn2Any(ori, ChanAnyFuncNok(gen))
}

// JoinAnyFuncErr returns a channel to receive
// everything from the given original channel `ori`
// as well as
// all results of generator `gen`
// until `err != nil`
// before close.
func JoinAnyFuncErr(ori <-chan Any, gen func() (Any, error)) (out <-chan Any) {
	return FanIn2Any(ori, ChanAnyFuncErr(gen))
}

// End of JoinAny fan-in's
// ===========================================================================
