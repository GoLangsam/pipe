
## Nomenklatura

- Make*

- Chan*		TODO => Fill* or Pour
- Pipe*
  - Tube
- Done*

- Join*		add *FunkNok & *FunkErr
- Fork*


---

- daisy		TODO => ????*
- merge
- SendProxy	TODO => Buff*



### Rupt* or Fuse*
- stop sending, emit `done` and keep draining
  - detector func(a) (a, bool)
  - incoming stop signal


rename
- *Any		=> *Anys
- *AnySlice	=> *AnySs
- *JoinAnyChan	=> *JoinAny
- *MakeAnyChan	=> *ChanAny - aka chan Any


