// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pipe

import "github.com/cheekybits/genny/generic"

type Any generic.Type

// ===========================================================================
// Beg of AnySupply channel object

// AnySupply is a
// supply channel
type AnySupply struct {
	dat chan Any
	//  chan struct{}
}

// MakeAnySupplyChan returns
// a (pointer to a) fresh
// unbuffered
// supply channel
func MakeAnySupplyChan() *AnySupply {
	d := new( AnySupply )
	d.dat = make(chan Any)
	// eq = make(chan struct{})
	return d
}

// MakeAnySupplyBuff returns
// a (pointer to a) fresh
// buffered (with capacity=`cap`)
// supply channel
func MakeAnySupplyBuff(cap int) *AnySupply {
	d := new( AnySupply )
	d.dat = make(chan Any, cap)
	// eq = make(chan struct{}, cap)
	return d
}

// Provide is the send method
// - aka "myAnyChan <- myAny"
func (c *AnySupply) Provide(dat Any) {
	// .req
	c.dat <- dat
}

// Receive is the receive operator as method
// - aka "myAny := <-myAnyChan"
func (c *AnySupply) Receive() (dat Any) {
	// eq <- struct{}{}
	return <-c.dat
}

// Request is the comma-ok multi-valued form of Receive and
// reports whether a received value was sent before the Any channel was closed
func (c *AnySupply) Request() (dat Any, open bool) {
	// eq <- struct{}{}
	dat, open = <-c.dat
	return dat, open
}

// Close closes the underlying Any channel
func (c *AnySupply) Close() {
	close(c.dat)
}

// Len reports the length of the underlying Any channel
func (c *AnySupply) Len() int {
	return len(c.dat)
}

// Cap reports the capacity of the underlying Any channel
func (c *AnySupply) Cap() int {
	return cap(c.dat)
}

// End of AnySupply channel object
// ===========================================================================
// ===========================================================================
// Beg of AnyDemand channel object

// AnyDemand is a
// demand channel
type AnyDemand struct {
	dat chan Any
	req chan struct{}
}

// MakeAnyDemandChan returns
// a (pointer to a) fresh
// unbuffered
// demand channel
func MakeAnyDemandChan() *AnyDemand {
	d := new( AnyDemand )
	d.dat = make(chan Any)
	d.req = make(chan struct{})
	return d
}

// MakeAnyDemandBuff returns
// a (pointer to a) fresh
// buffered (with capacity=`cap`)
// demand channel
func MakeAnyDemandBuff(cap int) *AnyDemand {
	d := new( AnyDemand )
	d.dat = make(chan Any, cap)
	d.req = make(chan struct{}, cap)
	return d
}

// Provide is the send method
// - aka "myAnyChan <- myAny"
func (c *AnyDemand) Provide(dat Any) {
	<-c.req
	c.dat <- dat
}

// Receive is the receive operator as method
// - aka "myAny := <-myAnyChan"
func (c *AnyDemand) Receive() (dat Any) {
	c.req <- struct{}{}
	return <-c.dat
}

// Request is the comma-ok multi-valued form of Receive and
// reports whether a received value was sent before the Any channel was closed
func (c *AnyDemand) Request() (dat Any, open bool) {
	c.req <- struct{}{}
	dat, open = <-c.dat
	return dat, open
}

// Close closes the underlying Any channel
func (c *AnyDemand) Close() {
	close(c.dat)
}

// Len reports the length of the underlying Any channel
func (c *AnyDemand) Len() int {
	return len(c.dat)
}

// Cap reports the capacity of the underlying Any channel
func (c *AnyDemand) Cap() int {
	return cap(c.dat)
}

// End of AnyDemand channel object
// ===========================================================================
// ===========================================================================
// Beg of AnyChannel interface

// AnyChannel represents a
// bidirectional
// channel of Any elements
type AnyChannel interface {
	AnyChanCore // close, len & cap
	receiverAny // Receive / Request
	providerAny // Provide
}
// Note: Embedding AnyReceiver and AnyProvider directly would result in error: duplicate method Len Cap Close

// AnyReceiver represents a
// receive-only
// channel of Any elements
// - aka `<-chan`
type AnyReceiver interface {
	AnyChanCore // close, len & cap
	receiverAny // Receive / Request
}

type receiverAny interface {
	Receive() (data Any)              // the receive operator as method - aka `MyAny := <-myreceiverAny`
	Request() (data Any, isOpen bool) // the multi-valued comma-ok receive - aka `MyAny, ok := <-myreceiverAny`
}

// AnyProvider represents a
// send-enabled
// channel of Any elements
// - aka `chan<-`
type AnyProvider interface {
	AnyChanCore // close, len & cap
	providerAny // Provide
}

type providerAny interface {
	Provide(data Any) // the send method - aka `MyAnyproviderAny <- MyAny`
}

// AnyChanCore represents basic methods common to every
// channel of Any elements
type AnyChanCore interface {
	Close()
	Len() int
	Cap() int
}

// Beg of AnyChannel interface
// ===========================================================================
