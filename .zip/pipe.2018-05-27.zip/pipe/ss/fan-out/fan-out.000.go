// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pipe

import (
	"github.com/cheekybits/genny/generic"
)

type Any generic.Type

// ===========================================================================
// Beg of FanAnyOut

// FanAnyOut returns a slice (of size = size) of channels
// each of which shall receive any inp before close.
func FanAnyOut(inp <-chan Any, size int) (outs [](<-chan Any)) {
	chas := make([]chan Any, size)
	for i := 0; i < size; i++ {
		chas[i] = make(chan Any)
	}

	// func(inp <-chan Any, outs ...chan<- Any) {
	go func(inp <-chan Any, outs ...chan Any) {
		defer func() {
			for o := range outs {
				close(outs[o])
			}
		}()
		for i := range inp {
			for o := range outs {
				outs[o] <- i
			}
		}
	}(inp, chas...)

	outs = make([]<-chan Any, size)
	for i := 0; i < size; i++ {
		outs[i] = chas[i]
	}

	return outs
}

// End of FanAnyOut
// ===========================================================================
