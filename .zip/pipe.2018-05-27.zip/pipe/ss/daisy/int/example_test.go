// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//go:generate genny -in .\..\daisy.go -out daisy.int.go -pkg pipe gen "Any=int"

package pipe

import (
	"fmt"

	"github.com/GoLangsam/pipe/ss/daisy/int"
)

func sendOne(snd chan<- int) {
	defer close(snd)
	snd <- 1 // send a 1
}

func sendTwo(snd chan<- int) {
	defer close(snd)
	snd <- 1 // send a 1
	snd <- 2 // send a 2
}

func ExampleDaisyAnyChain() {
	leftmost := make(chan int)

	tubeN := 10000
	tubeS := make([]pipe.TubeInt, tubeN)
	for i := 0; i < tubeN; i++ {
		tubeS[i] = func(left chan<- int, right <-chan int) { left <- 1 + <-right }
	}

	right := pipe.DaisyIntChain(leftmost, tubeS... ) // the chain - right to left!

	go sendTwo(right)

	fmt.Println(<-leftmost)
	// Output:
	// 10001
}

func main() {
	ExampleDaisyAnyChain()
}
