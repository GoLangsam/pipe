// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pipe

import "github.com/cheekybits/genny/generic"

type Any generic.Type

// TubeAny is the signature of linear (inner) pipe-network components
type TubeAny func(into chan<- Any, from <-chan Any)

// Example: the identity tube
var _ TubeAny = func(into chan<- Any, from <-chan Any) { into <- <-from }

// daisyAny returns a channel to receive all inp after having passed thru tube.
func daisyAny(inp <-chan Any, tube TubeAny) (out chan Any) {
	cha := make(chan Any)
	go tube(cha, inp)
	return cha
}

// DaisyAnyChain returns a channel to receive all inp after having passed thru all tubes.
func DaisyAnyChain(inp chan Any, tubes... TubeAny) (out chan Any) { // TODO geanny needs to respect variadic!
	cha := inp
	for _, tube := range tubes {
		cha = daisyAny(cha, tube)
	}
	return cha
}
