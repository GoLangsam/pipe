// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//go:generate bundle -pkg pipe -o .\..\pipe.go.gen .

////go:generate genny -in $GOFILE	-out ../s/$GOFILE.gen	gen "Anymode=*AnySupply"
////go:generate genny -in $GOFILE	-out ../l/$GOFILE.gen	gen "Anymode=*AnyDemand"
package pipe

import "github.com/cheekybits/genny/generic"

// import "github.com/cheekybits/genny/Xeneric"
//
// type Any Xeneric.Type

type Anymode generic.Type
type Any interface{}