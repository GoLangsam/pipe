// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pipe

import "github.com/cheekybits/genny/generic"

type Any generic.Type

// ===========================================================================
// Beg of MakeAny creators

// MakeAnyChan returns a new open channel
// (simply a 'chan Any' that is).
//
// Note: No 'Any-producer' is launched here yet! (as is in all the other functions).
//
// This is useful to easily create corresponding variables such as:
/*
   var myAnyPipelineStartsHere := MakeAnyChan()
   // ... lot's of code to design and build Your favourite "myAnyWorkflowPipeline"
   // ...
   // ... *before* You start pouring data into it, e.g. simply via:
   for drop := range water {
       myAnyPipelineStartsHere <- drop
   }
   close(myAnyPipelineStartsHere)
*/
// Hint: especially helpful, if Your piping library operates on some hidden (non-exported) type
// (or on a type imported from elsewhere - and You don't want/need or should(!) have to care.)
//
// Note: as always (except for PipeAnyBuffer) the channel is unbuffered.
//
func MakeAnyChan() (out chan Any) {
	return make(chan Any)
}

// End of MakeAny creators
// ===========================================================================
// ===========================================================================
// Beg of ChanAny producers

// ChanAny returns a channel to receive all inputs before close.
func ChanAny(inp ...Any) (out <-chan Any) {
	cha := make(chan Any)
	go chanAny(cha, inp...)
	return cha
}

func chanAny(out chan<- Any, inp ...Any) {
	defer close(out)
	for i := range inp {
		out <- inp[i]
	}
}

// ChanAnySlice returns a channel to receive all inputs before close.
func ChanAnySlice(inp ...[]Any) (out <-chan Any) {
	cha := make(chan Any)
	go chanAnySlice(cha, inp...)
	return cha
}

func chanAnySlice(out chan<- Any, inp ...[]Any) {
	defer close(out)
	for i := range inp {
		for j := range inp[i] {
			out <- inp[i][j]
		}
	}
}

// ChanAnyFuncNok returns a channel to receive all results of act until nok before close.
func ChanAnyFuncNok(act func() (Any, bool)) (out <-chan Any) {
	cha := make(chan Any)
	go chanAnyFuncNok(cha, act)
	return cha
}

func chanAnyFuncNok(out chan<- Any, act func() (Any, bool)) {
	defer close(out)
	for {
		res, ok := act() // Apply action
		if !ok {
			return
		}
		out <- res
	}
}

// ChanAnyFuncErr returns a channel to receive all results of act until err != nil before close.
func ChanAnyFuncErr(act func() (Any, error)) (out <-chan Any) {
	cha := make(chan Any)
	go chanAnyFuncErr(cha, act)
	return cha
}

func chanAnyFuncErr(out chan<- Any, act func() (Any, error)) {
	defer close(out)
	for {
		res, err := act() // Apply action
		if err != nil {
			return
		}
		out <- res
	}
}

// End of ChanAny producers
// ===========================================================================
// ===========================================================================
// Beg of DoneAny terminators

// DoneAny returns a channel to receive one signal before close after inp has been drained.
func DoneAny(inp <-chan Any) (done <-chan struct{}) {
	sig := make(chan struct{})
	go doitAny(sig, inp)
	return sig
}

func doitAny(done chan<- struct{}, inp <-chan Any) {
	defer close(done)
	for i := range inp {
		_ = i // Drain inp
	}
	done <- struct{}{}
}

// DoneAnySlice returns a channel which will receive a slice
// of all the Anys received on inp channel before close.
// Unlike DoneAny, a full slice is sent once, not just an event.
func DoneAnySlice(inp <-chan Any) (done <-chan []Any) {
	sig := make(chan []Any)
	go doitAnySlice(sig, inp)
	return sig
}

func doitAnySlice(done chan<- []Any, inp <-chan Any) {
	defer close(done)
	slice := []Any{}
	for i := range inp {
		slice = append(slice, i)
	}
	done <- slice
}

// DoneAnyFunc returns a channel to receive one signal before close after act has been applied to all inp.
func DoneAnyFunc(inp <-chan Any, act func(a Any)) (done <-chan struct{}) {
	sig := make(chan struct{})
	if act == nil {
		act = func(a Any) { return }
	}
	go doitAnyFunc(sig, inp, act)
	return sig
}

func doitAnyFunc(done chan<- struct{}, inp <-chan Any, act func(a Any)) {
	defer close(done)
	for i := range inp {
		act(i) // Apply action
	}
	done <- struct{}{}
}

// End of DoneAny terminators
// ===========================================================================
// ===========================================================================
// Beg of PipeAny functions

// PipeAnyBuffer returns a buffered channel with capacity cap to receive all inp before close.
func PipeAnyBuffer(inp <-chan Any, cap int) (out <-chan Any) {
	cha := make(chan Any, cap)
	go pipeAnyBuffer(cha, inp)
	return cha
}

func pipeAnyBuffer(out chan<- Any, inp <-chan Any) {
	defer close(out)
	for i := range inp {
		out <- i
	}
}

// PipeAnyFunc returns a channel to receive every result of act applied to inp before close.
// Note: it 'could' be PipeAnyMap for functional people,
// but 'map' has a very different meaning in go lang.
func PipeAnyFunc(inp <-chan Any, act func(a Any) Any) (out <-chan Any) {
	cha := make(chan Any)
	if act == nil {
		act = func(a Any) Any { return a }
	}
	go pipeAnyFunc(cha, inp, act)
	return cha
}

func pipeAnyFunc(out chan<- Any, inp <-chan Any, act func(a Any) Any) {
	defer close(out)
	for i := range inp {
		out <- act(i)
	}
}

// End of PipeAny functions
// ===========================================================================
// ===========================================================================
// Beg of ForkAny functions

// ForkAny returns two channels to receive every result of inp before close.
//  Note: Yes, it is a VERY simple fanout - but sometimes all You need.
func ForkAny(inp <-chan Any) (out1, out2 <-chan Any) {
	cha1 := make(chan Any)
	cha2 := make(chan Any)
	go forkAny(cha1, cha2, inp)
	return cha1, cha2
}

func forkAny(out1, out2 chan<- Any, inp <-chan Any) {
	defer close(out1)
	defer close(out2)
	for i := range inp {
		out1 <- i
		out2 <- i
	}
}

// End of ForkAny functions
// ===========================================================================
