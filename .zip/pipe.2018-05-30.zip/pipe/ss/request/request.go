// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package request

import (
	"github.com/cheekybits/genny/generic"
)

type Any generic.Type

// ===========================================================================
// Beg of Request

type Request struct {
	fn func() Any // The operation to perform
	c chan Any // The channel on which to return the result
}


func requester(work chan Request) {
	cha := make(chan Any)
	for {
		// time.Sleep ....
		work <- Request{workFn, cha}
		result := <- cha
		furtherProcess(result)
	}
}

func(w *Worker) work(done chan *Worker) {
	for {
		req := <-w.requests
		req.c <- req.fn()
		done <- w
	}
}

// End of Request
// ===========================================================================
// ===========================================================================
// Beg of Balancer

type Pool []*Worker

// make Pool implement Heap: Len Push Pop Swap Less
func(p Pool) Len() int {
	return len(p)
}

func(p Pool) Less(i, j int) bool {
	return p[i].pending < p[j].pending
}

// ===========================================================================

type Worker struct {

}

// ===========================================================================

type Balancer struct {
	pool Pool
	done chan *Worker
}

func(b *Balancer) balance(work chan Request) {
	for {
		select {
		case req := <- work:
			b.dispatch(req)
		case w := b.done:
			b.completed(w)
		}
	}
}

// dispatch sends Request to Worker
func(b *Balancer) dispatch(req Request) {
	w := heap.Pop(&b.pool).(*Worker) // least loaded worker ...
	w.requests <- req                // ... is assigned the taks
	w.pending++			 // one more in it's queue
	heap.Push(&b.pool, w)		 // put it back in the heap
}

// completed is the Job: update the Heap
func(b *Balancer) completed(w *Worker) {
	w.pending--                   // one fewer in it's queue
	heap.Remove(&b.pool, w.index) // remove it from Heap
	heap.Push(&b.pool, w)         // put it back where it belongs
}