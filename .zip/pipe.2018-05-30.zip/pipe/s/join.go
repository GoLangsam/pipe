// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pipe

// ===========================================================================
// Beg of JoinAny fan-in's

func joinAny(done chan<- struct{}, out *AnySupply, inp ...Any) {
	defer close(done)
	for i := range inp {
		out.Provide(inp[i])
	}
	done <- struct{}{}
}

// JoinAny sends inputs on the given out channel and returns a done channel to receive one signal when inp has been drained
func JoinAny(out *AnySupply, inp ...Any) (done <-chan struct{}) {
	sig := make(chan struct{})
	go joinAny(sig, out, inp...)
	return sig
}

func joinAnySlice(done chan<- struct{}, out *AnySupply, inp ...[]Any) {
	defer close(done)
	for i := range inp {
		for j := range inp[i] {
			out.Provide(inp[i][j])
		}
	}
	done <- struct{}{}
}

// JoinAnySlice sends inputs on the given out channel and returns a done channel to receive one signal when inp has been drained
func JoinAnySlice(out *AnySupply, inp ...[]Any) (done <-chan struct{}) {
	sig := make(chan struct{})
	go joinAnySlice(sig, out, inp...)
	return sig
}

func joinAnyChan(done chan<- struct{}, out *AnySupply, inp *AnySupply) {
	defer close(done)
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		out.Provide(i)
	}
	done <- struct{}{}
}

// JoinAnyChan sends inputs on the given out channel and returns a done channel to receive one signal when inp has been drained
func JoinAnyChan(out *AnySupply, inp *AnySupply) (done <-chan struct{}) {
	sig := make(chan struct{})
	go joinAnyChan(sig, out, inp)
	return sig
}

// End of JoinAny fan-in's
// ===========================================================================
