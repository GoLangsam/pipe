// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pipe

// ===========================================================================
// Beg of ChanAny producers

// ChanAny returns a channel to receive all inputs before close.
func ChanAny(inp ...Any) (out <-chan Any) {
	cha := make(chan Any)
	go func(out chan<- Any, inp ...Any) {
		defer close(out)
		for i := range inp {
			out <- inp[i]
		}
	}(cha, inp)
	return cha
}

// ChanAnySlice returns a channel to receive all inputs before close.
func ChanAnySlice(inp ...[]Any) (out <-chan Any) {
	cha := make(chan Any)
	go func(out chan<- Any, inp ...[]Any) {
		defer close(out)
		for i := range inp {
			for j := range inp[i] {
				out <- inp[i][j]
			}
		}
	}(cha, inp...)
	return cha
}

// ChanAnyFuncNok returns a channel to receive all results of act until nok before close.
func ChanAnyFuncNok(act func() (Any, bool)) (out <-chan Any) {
	cha := make(chan Any)
	go func(out chan<- Any, act func() (Any, bool)) {
		defer close(out)
		for {
			res, ok := act() // Apply action
			if !ok {
				return
			}
			out <- res
		}
	}(cha, act)
	return cha
}

// ChanAnyFuncErr returns a channel to receive all results of act until err != nil before close.
func ChanAnyFuncErr(act func() (Any, error)) (out <-chan Any) {
	cha := make(chan Any)
	go func(out chan<- Any, act func() (Any, error)) {
		defer close(out)
		for {
			res, err := act() // Apply action
			if err != nil {
				return
			}
			out <- res
		}
	}(cha, act)
	return cha
}

// End of ChanAny producers
// ===========================================================================
