# [`pipe/ss.notyet`](./) - a better way to do it

- looks very good by now, does it not?
- just one more systematic change - driven by paranoia ;-)
- and a few subtle corrections and improvements.

Have a look at why and how to [evolve](../readme/evolve.md).

```text
	Thus: Think further along these lines...
	Just: Refrain from coding what You see.
```

---
[Back to overview](../readme/overview.md)
