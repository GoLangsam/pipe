# `v0` - The original version

This copy of [`qvl.io/httpsyet/httpsyet`](https://github.com/qvl/httpsyet) needs only one (canonical) change:
the import of the package in `crawler_test.go` needs to be adjusted..

----
[Back to Overview](../)