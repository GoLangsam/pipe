// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package balance

func ExampleBalancer() {

	workFn := func() (a Any) { return }

	requester := func(work chan<- Request) {
		cha := make(chan Any)
		for {
			// time.Sleep ....
			work <- Request{workFn, cha} // send a work request
			result := <-cha              // wait for answer
			_ = result                   // furtherProcess(result)
		}
	}

	requester(New(10))

}
