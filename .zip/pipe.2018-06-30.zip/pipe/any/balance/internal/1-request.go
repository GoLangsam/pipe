// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package balance

// ===========================================================================
// Beg of Request

// Request is a function to be applied and channel on which to return the result.
type Request struct {
	fn func() item // operation to perform
	c  chan item   // channel on which to return result
}

// End of Request
// ===========================================================================
