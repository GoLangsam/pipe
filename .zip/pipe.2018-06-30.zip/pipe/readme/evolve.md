# An evolution

- First steps:
	- [ssss](../ssss.none/) a first 'theoretical' approach - does not get You anywhere
	- [sss](../sss.naive/) a naive approach - as seen in popular slides, talks and blogs
	- [ss](../ss.notyet/) a better way to do it

- The essence:
	- [s](../s/) is for You to use - [Batteries](batteries.md) included!
	- [m](../m/) prefer to chain methods? - Same [batteries](batteries.md) included!

- Soon to come:
	- [l](../l/) *lazy* evolution

---
[Back to overview](overview.md)


