# Overview

- [Prolog](prolog.md)

---
- [Adverts](adverts.md) and advices - from a master(?)

---
- [Intro](intro.md)
- [Basics](basics.md)
- [Batteries](batteries.md) - included!

---
- [Directories](directories.md) - Where is what? & What is where?

---
- [An evolution](evolve.md)
- [Seen in the wild](in-the-wild.md) - slides from a master - too short & too simple
- [Pitfalls](pitfalls.md) and popular easy-to-do mistakes - vaccines and protective habits

---
- [Generic](generic.md)
- [Closures](closures.md)

---
- [Other related works](others.md)
- [Resources](resources.md)
- [People](people.md)

---
- [Asciiart](asciiart.md) - just for the fun of it.
- [ToDo](ToDo.md) - all kinds of notes and scribblings

---
[Back to overview](overview.md) - just kidding - this *is* the overview ;-)
