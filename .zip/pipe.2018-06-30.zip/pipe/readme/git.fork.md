# Git fork

### 0. Fork:

### 1. Get a local clone your fork:

    git clone git@github.com:YOUR-USERNAME/YOUR-FORKED-REPO.git

### 2. Add the remote original repository as `upstream` to your forked repository: 

    cd into/cloned/fork-repo
    git remote add upstream git://github.com/ORIGINAL-DEV-USERNAME/REPO-YOU-FORKED-FROM.git

### 3. Obtain latest changes from `upstream`
    git fetch upstream

### 4. Update your local clone of the fork from original `upstream` repo to keep up with their changes:

    git pull upstream master

### 5. Update your fork:

    git push	

- https://help.github.com/articles/configuring-a-remote-for-a-fork/
- https://help.github.com/articles/syncing-a-fork/
