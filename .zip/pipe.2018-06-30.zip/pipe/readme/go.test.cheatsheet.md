
```console
$ go test -bench=.

$ go test -bench=. -cpuprofile cpu.prof
$ go tool pprof -svg cpu.prof > cpu.svg

$ go test -bench=. -trace trace.out
$ go tool trace trace.out

$ go test -race
PASS

$ git gc --aggressive
```
