// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pipe

// ===========================================================================
// Beg of JoinAny fan-in's

// JoinAny sends inputs on the given channel and returns a done channel to receive one signal when inp has been drained
func JoinAny(ori <-chan Any, inp ...Any) (out <-chan Any) {
	return FanIn2Any(ori, ChanAny(inp...))
}

// JoinAnySlice sends inputs on the given out channel and returns a done channel to receive one signal when inp has been drained
func JoinAnySlice(ori <-chan Any, inp ...[]Any) (out <-chan Any) {
	return FanIn2Any(ori, ChanAnySlice(inp...))
}

// JoinAnyChan sends inputs on the given out channel and returns a done channel to receive one signal when inp has been drained
func JoinAnyChan(ori <-chan Any, inp <-chan Any) (out <-chan Any) {
	return FanIn2Any(ori, inp)
}

// and more
// JoinAnyFuncNok ...
func JoinAnyFuncNok(ori <-chan Any, act func() (Any, bool)) (out <-chan Any) {
	return FanIn2Any(ori, ChanAnyFuncNok(act))
}

// JoinAnyFuncErr ...
func JoinAnyFuncErr(ori <-chan Any, act func() (Any, error)) (out <-chan Any) {
	return FanIn2Any(ori, ChanAnyFuncErr(act))
}

// End of JoinAny fan-in's
// ===========================================================================
