// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pipe

// ===========================================================================
// Beg of has nil versions

// ChanAnyFuncNil returns a channel to receive all results of act until nil before close.
func ChanAnyFuncNil(act func() (Any, bool)) (out <-chan Any) {
	cha := make(chan Any)
	go chanAnyFuncNil(cha, act)
	return cha
}

func chanAnyFuncNok(out chan<- Any, act func() (Any, bool)) {
	defer close(out)
	for {
		res := act() // Apply action
		if res == nil {
			return
		}
		out <- res
	}
}

// End of has nil versions
// ===========================================================================
