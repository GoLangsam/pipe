
General: 
https://github.com/golang/go/wiki/CodeReviewComments - a laundry list of common mistakes, not a style guide.
http://golang.org/doc/effective_go.html#package-names

---

### 0. Fork:

### 1. Get a local clone your fork:

    git clone git@github.com:YOUR-USERNAME/YOUR-FORKED-REPO.git

### 2. Add the remote original repository as `upstream` to your forked repository: 

    cd into/cloned/fork-repo
    git remote add upstream git://github.com/ORIGINAL-DEV-USERNAME/REPO-YOU-FORKED-FROM.git

### 3. Obtain latest changes from `upstream`
    git fetch upstream

### 4. Update your local clone of the fork from original `upstream` repo to keep up with their changes:

    git pull upstream master

### 5. Update your fork:

    git push	

- https://help.github.com/articles/configuring-a-remote-for-a-fork/
- https://help.github.com/articles/syncing-a-fork/

rfc1925.txt
- (10)  One size never fits all.

## Nomenklatura

- Make*

- Chan*		TODO => Fill* or Pour
- Pipe*
  - Tube
- Done*
  - Fini	TODO

- Join*		add *FunkNok & *FunkErr
- Fork*


---

- daisy		TODO => ????*
- merge
- SendProxy	TODO => Buff*



### Rupt* or Fuse*
- stop sending, emit `done` and keep draining
  - detector func(a) (a, bool)
  - incoming stop signal


rename
- *Any		=> *Anys
- *AnySlice	=> *AnySs
- *JoinAnyChan	=> *JoinAny
- *MakeAnyChan	=> *ChanAny - aka chan Any


