// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pipe

// ===========================================================================
// Beg of JoinAny fan-in's

// JoinAny sends inputs on the given channel and returns a done channel to receive one signal when inp has been drained
func JoinAny(ori Anymode, inp ...Any) (out Anymode) {
	return FanIn2Any(ori, ChanAny(inp...))
}

// JoinAnySlice sends inputs on the given out channel and returns a done channel to receive one signal when inp has been drained
func JoinAnySlice(ori Anymode, inp ...[]Any) (out Anymode) {
	return FanIn2Any(ori, ChanAnySlice(inp...))
}

// JoinAnyChan sends inputs on the given out channel and returns a done channel to receive one signal when inp has been drained
func JoinAnyChan(ori Anymode, inp Anymode) (out Anymode) {
	return FanIn2Any(ori, inp)
}

// and more
// JoinAnyFuncNok ...
func JoinAnyFuncNok(ori Anymode, act func() (Any, bool)) (out Anymode) {
	return FanIn2Any(ori, ChanAnyFuncNok(act))
}

// JoinAnyFuncErr ...
func JoinAnyFuncErr(ori Anymode, act func() (Any, error)) (out Anymode) {
	return FanIn2Any(ori, ChanAnyFuncErr(act))
}

// End of JoinAny fan-in's
// ===========================================================================
