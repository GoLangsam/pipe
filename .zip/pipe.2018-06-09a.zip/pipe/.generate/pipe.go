// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//go:generate genny -in $GOFILE	-out ../s/internal/$GOFILE	gen "Anymode=*AnySupply"
//go:generate genny -in $GOFILE	-out ../l/internal/$GOFILE	gen "Anymode=*AnyDemand"

package pipe

import (
	"github.com/cheekybits/genny/generic"
)

type Anymode generic.Type

// ===========================================================================
// Beg of ChanAny producers

// ChanAny returns a channel to receive all inputs before close.
func ChanAny(inp ...Any) (out Anymode) {
	cha := MakeAnymodeChan()
	go chanAny(cha, inp...)
	return cha
}

func chanAny(out Anymode, inp ...Any) {
	defer out.Close()
	for i := range inp {
		out.Provide(inp[i])
	}
}

// ChanAnySlice returns a channel to receive all inputs before close.
func ChanAnySlice(inp ...[]Any) (out Anymode) {
	cha := MakeAnymodeChan()
	go chanAnySlice(cha, inp...)
	return cha
}

func chanAnySlice(out Anymode, inp ...[]Any) {
	defer out.Close()
	for i := range inp {
		for j := range inp[i] {
			out.Provide(inp[i][j])
		}
	}
}

// ChanAnyFuncNok returns a channel to receive all results of act until nok before close.
func ChanAnyFuncNok(act func() (Any, bool)) (out Anymode) {
	cha := MakeAnymodeChan()
	go chanAnyFuncNok(cha, act)
	return cha
}

func chanAnyFuncNok(out Anymode, act func() (Any, bool)) {
	defer out.Close()
	for {
		res, ok := act() // Apply action
		if !ok {
			return
		}
		out.Provide(res)
	}
}

// ChanAnyFuncErr returns a channel to receive all results of act until err != nil before close.
func ChanAnyFuncErr(act func() (Any, error)) (out Anymode) {
	cha := MakeAnymodeChan()
	go chanAnyFuncErr(cha, act)
	return cha
}

func chanAnyFuncErr(out Anymode, act func() (Any, error)) {
	defer out.Close()
	for {
		res, err := act() // Apply action
		if err != nil {
			return
		}
		out.Provide(res)
	}
}

// End of ChanAny producers
// ===========================================================================

// ===========================================================================
// Beg of PipeAny functions

// PipeAnyFunc returns a channel to receive every result of act applied to inp before close.
// Note: it 'could' be PipeAnyMap for functional people,
// but 'map' has a very different meaning in go lang.
func PipeAnyFunc(inp Anymode, act func(a Any) Any) (out Anymode) {
	cha := MakeAnymodeChan()
	if act == nil {
		act = func(a Any) Any { return a }
	}
	go pipeAnyFunc(cha, inp, act)
	return cha
}

func pipeAnyFunc(out Anymode, inp Anymode, act func(a Any) Any) {
	defer out.Close()
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		out.Provide(act(i))
	}
}

// PipeAnyBuffer returns a buffered channel with capacity cap to receive all inp before close.
func PipeAnyBuffer(inp Anymode, cap int) (out Anymode) {
	cha := MakeAnymodeBuff(cap)
	go pipeAnyBuffer(cha, inp)
	return cha
}

func pipeAnyBuffer(out Anymode, inp Anymode) {
	defer out.Close()
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		out.Provide(i)
	}
}

// End of PipeAny functions
// ===========================================================================

// ===========================================================================
// Beg of TubeAny closures

// TubeAnyFunc returns a closure around PipeAnyFunc (_, act).
func TubeAnyFunc(act func(a Any) Any) (tube func(inp Anymode) (out Anymode)) {

	return func(inp Anymode) (out Anymode) {
		return PipeAnyFunc(inp, act)
	}
}

// TubeAnyBuffer returns a closure around PipeAnyBuffer (_, cap).
func TubeAnyBuffer(cap int) (tube func(inp Anymode) (out Anymode)) {

	return func(inp Anymode) (out Anymode) {
		return PipeAnyBuffer(inp, cap)
	}
}

// End of TubeAny closures
// ===========================================================================

// ===========================================================================
// Beg of DoneAny terminators

// DoneAny returns a channel to receive one signal before close after inp has been drained.
func DoneAny(inp Anymode) (done <-chan struct{}) {
	sig := make(chan struct{})
	go doitAny(sig, inp)
	return sig
}

func doitAny(done chan<- struct{}, inp Anymode) {
	defer close(done)
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		_ = i // Drain inp
	}
	done <- struct{}{}
}

// DoneAnySlice returns a channel which will receive a slice
// of all the Anys received on inp channel before close.
// Unlike DoneAny, a full slice is sent once, not just an event.
func DoneAnySlice(inp Anymode) (done <-chan []Any) {
	sig := make(chan []Any)
	go doitAnySlice(sig, inp)
	return sig
}

func doitAnySlice(done chan<- []Any, inp Anymode) {
	defer close(done)
	slice := []Any{}
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		slice = append(slice, i)
	}
	done <- slice
}

// DoneAnyFunc returns a channel to receive one signal before close after act has been applied to all inp.
func DoneAnyFunc(inp Anymode, act func(a Any)) (done <-chan struct{}) {
	sig := make(chan struct{})
	if act == nil {
		act = func(a Any) { return }
	}
	go doitAnyFunc(sig, inp, act)
	return sig
}

func doitAnyFunc(done chan<- struct{}, inp Anymode, act func(a Any)) {
	defer close(done)
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		act(i) // Apply action
	}
	done <- struct{}{}
}

// End of DoneAny terminators
// ===========================================================================

// ===========================================================================
// Beg of FiniAny closures

// FiniAny returns a closure around `DoneAny(_)`.
func FiniAny() func(inp Anymode) (done <-chan struct{}) {

	return func(inp Anymode) (done <-chan struct{}) {
		return DoneAny(inp)
	}
}

// FiniAnySlice returns a closure around `DoneAnySlice(_)`.
func FiniAnySlice() func(inp Anymode) (done <-chan []Any) {

	return func(inp Anymode) (done <-chan []Any) {
		return DoneAnySlice(inp)
	}
}

// FiniAnyFunc returns a closure around `DoneAnyFunc(_, act)`.
func FiniAnyFunc(act func(a Any)) func(inp Anymode) (done <-chan struct{}) {

	return func(inp Anymode) (done <-chan struct{}) {
		return DoneAnyFunc(inp, act)
	}
}

// End of FiniAny closures
// ===========================================================================

// ===========================================================================
// Beg of ForkAny functions

// ForkAny returns two channels to receive every result of inp before close.
//  Note: Yes, it is a VERY simple fanout - but sometimes all You need.
func ForkAny(inp Anymode) (out1, out2 Anymode) {
	cha1 := MakeAnymodeChan()
	cha2 := MakeAnymodeChan()
	go forkAny(cha1, cha2, inp)
	return cha1, cha2
}

func forkAny(out1, out2 Anymode, inp Anymode) {
	defer out1.Close()
	defer out2.Close()
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		out1.Provide(i)
		out2.Provide(i)
	}
}

// End of ForkAny functions
// ===========================================================================

// ===========================================================================
// FanIn2Any returns a channel to receive all to receive all from both `inp1` and `inp2` before close.
func FanIn2Any(inp1, inp2 Anymode) (out Anymode) {
	cha := MakeAnymodeChan()
	go fanIn2Any(cha, inp1, inp2)
	return cha
}

/* not used any more - kept for reference only.
// fanin2Any as seen in Go Concurrency Patterns
func fanin2Any(out chan<- Any, inp1, inp2 Anymode) {
	for {
		select {
		case e := <-inp1:
			out <- e
		case e := <-inp2:
			out <- e
		}
	}
} */

func fanIn2Any(out Anymode, inp1, inp2 Anymode) {
	defer out.Close()

	var (
		closed bool // we found a chan closed
		ok     bool // did we read sucessfully?
		e      Any  // what we've read
	)

	for !closed {
		select {
		case e, ok = <-inp1.dat:
			if ok {
				out.Receive(e)
			} else {
				inp1 = inp2   // swap inp2 into inp1
				closed = true // break out of the loop
			}
		case e, ok = <-inp2.dat:
			if ok {
				out.Receive(e)
			} else {
				closed = true // break out of the loop				}
			}
		}
	}

	// inp1 might not be closed yet. Drain it.
	for e, ok = inp.Request(); ok; i, ok = inp.Request() {
		out.Receive(e)
	}
}

// ===========================================================================

// ===========================================================================
// Beg of JoinAny fan-in's

// JoinAny sends inputs on the given channel and returns a done channel to receive one signal when inp has been drained
func JoinAny(ori Anymode, inp ...Any) (out Anymode) {
	return FanIn2Any(ori, ChanAny(inp...))
}

// JoinAnySlice sends inputs on the given out channel and returns a done channel to receive one signal when inp has been drained
func JoinAnySlice(ori Anymode, inp ...[]Any) (out Anymode) {
	return FanIn2Any(ori, ChanAnySlice(inp...))
}

// JoinAnyChan sends inputs on the given out channel and returns a done channel to receive one signal when inp has been drained
func JoinAnyChan(ori Anymode, inp Anymode) (out Anymode) {
	return FanIn2Any(ori, inp)
}

// and more
// JoinAnyFuncNok ...
func JoinAnyFuncNok(ori Anymode, act func() (Any, bool)) (out Anymode) {
	return FanIn2Any(ori, ChanAnyFuncNok(act))
}

// JoinAnyFuncErr ...
func JoinAnyFuncErr(ori Anymode, act func() (Any, error)) (out Anymode) {
	return FanIn2Any(ori, ChanAnyFuncErr(act))
}

// End of JoinAny fan-in's
// ===========================================================================
//
