// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pipe

import "github.com/cheekybits/genny/generic"

type Any generic.Type

// TubeAny is the signature of linear (inner) pipe-network components
type TubeAny func(into chan<- Any, from <-chan Any)

// Example: the identity tube - see `samesame` below
var _ TubeAny = func(into chan<- Any, from <-chan Any) { into <- <-from }

// daisyAny returns a channel to receive all inp after having passed thru tube.
func daisyAny(inp <-chan Any, tube TubeAny) (out chan Any) {
	cha := make(chan Any)
	go tube(cha, inp)
	return cha
}

// DaisyChainAny returns a channel to receive all inp
// after having passed somany times thru the tube(s)
// before close
//
// Note: If `somany` is less than 1 or no `tubes` are provided,
// `out` shall receive elements from `inp` unaltered (as a convenience)
func DaisyChainAny(inp chan Any, somany int, tubes... TubeAny) (out chan Any) { // TODO geanny needs a leading space!
	cha := inp

	if somany < 1 || len(tubes) < 1 {
		samesame := func(into chan<- Any, from <-chan Any) { into <- <-from }
		cha = daisyAny(cha, samesame)
	} else {
		for i := 0; i < somany; i++ {
			for _, tube := range tubes {
				cha = daisyAny(cha, tube)
			}
		}
	}
	return cha
}
