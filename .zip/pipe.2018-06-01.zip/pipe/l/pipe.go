// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pipe

import "github.com/cheekybits/genny/generic"

type Any generic.Type

// ===========================================================================
// Beg of AnyDemand

// AnyDemand is a
// demand channel
type AnyDemand struct {
	dat chan Any
	req chan struct{}
}

// MakeAnyDemandChan returns
// a (pointer to a) fresh
// unbuffered
// demand channel
func MakeAnyDemandChan() *AnyDemand {
	d := new( AnyDemand )
	d.dat = make(chan Any)
	d.req = make(chan struct{})
	return d
}

// MakeAnyDemandBuff returns
// a (pointer to a) fresh
// buffered (with capacity=`cap`)
// demand channel
func MakeAnyDemandBuff(cap int) *AnyDemand {
	d := new( AnyDemand )
	d.dat = make(chan Any, cap)
	d.req = make(chan struct{}, cap)
	return d
}

// Provide is the send method
// - aka "myAnyChan <- myAny"
func (c *AnyDemand) Provide(dat Any) {
	<-c.req
	c.dat <- dat
}

// Receive is the receive operator as method
// - aka "myAny := <-myAnyChan"
func (c *AnyDemand) Receive() (dat Any) {
	c.req <- struct{}{}
	return <-c.dat
}

// Request is the comma-ok multi-valued form of Receive and
// reports whether a received value was sent before the Any channel was closed
func (c *AnyDemand) Request() (dat Any, open bool) {
	c.req <- struct{}{}
	dat, open = <-c.dat
	return dat, open
}

// Close closes the underlying Any channel
func (c *AnyDemand) Close() {
	close(c.dat)
}

// Cap reports the capacity of the underlying Any channel
func (c *AnyDemand) Cap() int {
	return cap(c.dat)
}

// Len reports the length of the underlying Any channel
func (c *AnyDemand) Len() int {
	return len(c.dat)
}

// End of AnyDemand
// ===========================================================================
// ===========================================================================
// Beg of MakeAny creators

// MakeAnyChan returns a new open channel
// (simply a 'chan Any' that is).
//
// Note: No 'Any-producer' is launched here yet! (as is in all the other functions).
//
// This is useful to easily create corresponding variables such as:
/*
   var myAnyPipelineStartsHere := MakeAnyChan()
   // ... lot's of code to design and build Your favourite "myAnyWorkflowPipeline"
   // ...
   // ... *before* You start pouring data into it, e.g. simply via:
   for drop := range water {
       myAnyPipelineStartsHere <- drop
   }
   close(myAnyPipelineStartsHere)
*/
// Hint: especially helpful, if Your piping library operates on some hidden (non-exported) type
// (or on a type imported from elsewhere - and You don't want/need or should(!) have to care.)
//
// Note: as always (except for PipeAnyBuffer) the channel is unbuffered.
//
func MakeAnyChan() (out *SChAny) {
	return MakeAnySupplyChan()
}

// End of MakeAny creators
// ===========================================================================
// ===========================================================================
// Beg of ChanAny producers

func chanAny(out *AnyDemand, inp ...Any) {
	defer out.Close()
	for i := range inp {
		out.Provide(inp[i])
	}
}

// ChanAny returns a channel to receive all inputs before close.
func ChanAny(inp ...Any) (out *AnyDemand) {
	cha := MakeAnyDemandChan()
	go chanAny(cha, inp...)
	return cha
}

func chanAnySlice(out *AnyDemand, inp ...[]Any) {
	defer out.Close()
	for i := range inp {
		for j := range inp[i] {
			out.Provide(inp[i][j])
		}
	}
}

// ChanAnySlice returns a channel to receive all inputs before close.
func ChanAnySlice(inp ...[]Any) (out *AnyDemand) {
	cha := MakeAnyDemandChan()
	go chanAnySlice(cha, inp...)
	return cha
}

func chanAnyFuncNok(out *AnyDemand, act func() (Any, bool)) {
	defer out.Close()
	for {
		res, ok := act() // Apply action
		if !ok {
			return
		}
		out.Provide(res)
	}
}

// ChanAnyFuncNok returns a channel to receive all results of act until nok before close.
func ChanAnyFuncNok(act func() (Any, bool)) (out *AnyDemand) {
	cha := MakeAnyDemandChan()
	go chanAnyFuncNok(cha, act)
	return cha
}

func chanAnyFuncErr(out *AnyDemand, act func() (Any, error)) {
	defer out.Close()
	for {
		res, err := act() // Apply action
		if err != nil {
			return
		}
		out.Provide(res)
	}
}

// ChanAnyFuncErr returns a channel to receive all results of act until err != nil before close.
func ChanAnyFuncErr(act func() (Any, error)) (out *AnyDemand) {
	cha := MakeAnyDemandChan()
	go chanAnyFuncErr(cha, act)
	return cha
}

// End of ChanAny producers
// ===========================================================================
// ===========================================================================
// Beg of JoinAny fan-in's

func joinAny(done chan<- struct{}, out *AnyDemand, inp ...Any) {
	defer close(done)
	for i := range inp {
		out.Provide(inp[i])
	}
	done <- struct{}{}
}

// JoinAny sends inputs on the given out channel and returns a done channel to receive one signal when inp has been drained
func JoinAny(out *AnyDemand, inp ...Any) (done <-chan struct{}) {
	sig := make(chan struct{})
	go joinAny(sig, out, inp...)
	return sig
}

func joinAnySlice(done chan<- struct{}, out *AnyDemand, inp ...[]Any) {
	defer close(done)
	for i := range inp {
		for j := range inp[i] {
			out.Provide(inp[i][j])
		}
	}
	done <- struct{}{}
}

// JoinAnySlice sends inputs on the given out channel and returns a done channel to receive one signal when inp has been drained
func JoinAnySlice(out *AnyDemand, inp ...[]Any) (done <-chan struct{}) {
	sig := make(chan struct{})
	go joinAnySlice(sig, out, inp...)
	return sig
}

func joinAnyChan(done chan<- struct{}, out *AnyDemand, inp *AnyDemand) {
	defer close(done)
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		out.Provide(i)
	}
	done <- struct{}{}
}

// JoinAnyChan sends inputs on the given out channel and returns a done channel to receive one signal when inp has been drained
func JoinAnyChan(out *AnyDemand, inp *AnyDemand) (done <-chan struct{}) {
	sig := make(chan struct{})
	go joinAnyChan(sig, out, inp)
	return sig
}

// End of JoinAny fan-in's
// ===========================================================================
// ===========================================================================
// Beg of DoneAny terminators

func doitAny(done chan<- struct{}, inp *AnyDemand) {
	defer close(done)
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		_ = i // Drain inp
	}
	done <- struct{}{}
}

// DoneAny returns a channel to receive one signal before close after inp has been drained.
func DoneAny(inp *AnyDemand) (done <-chan struct{}) {
	sig := make(chan struct{})
	go doitAny(sig, inp)
	return sig
}

func doitAnySlice(done chan<- []Any, inp *AnyDemand) {
	defer close(done)
	slice := []Any{}
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		slice = append(slice, i)
	}
	done <- slice
}

// DoneAnySlice returns a channel which will receive a slice
// of all the Anys received on inp channel before close.
// Unlike DoneAny, a full slice is sent once, not just an event.
func DoneAnySlice(inp *AnyDemand) (done <-chan []Any) {
	sig := make(chan []Any)
	go doitAnySlice(sig, inp)
	return sig
}

func doitAnyFunc(done chan<- struct{}, inp *AnyDemand, act func(a Any)) {
	defer close(done)
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		act(i) // Apply action
	}
	done <- struct{}{}
}

// DoneAnyFunc returns a channel to receive one signal before close after act has been applied to all inp.
func DoneAnyFunc(inp *AnyDemand, act func(a Any)) (done <-chan struct{}) {
	sig := make(chan struct{})
	if act == nil {
		act = func(a Any) { return }
	}
	go doitAnyFunc(sig, inp, act)
	return sig
}

// End of DoneAny terminators
// ===========================================================================
// ===========================================================================
// Beg of PipeAny functions

func pipeAnyBuffer(out *AnyDemand, inp *AnyDemand) {
	defer out.Close()
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		out.Provide(i)
	}
}

// PipeAnyBuffer returns a buffered channel with capacity cap to receive all inp before close.
func PipeAnyBuffer(inp *AnyDemand, cap int) (out *AnyDemand) {
	cha := MakeAnyDemandBuff(cap)
	go pipeAnyBuffer(cha, inp)
	return cha
}

func pipeAnyFunc(out *AnyDemand, inp *AnyDemand, act func(a Any) Any) {
	defer out.Close()
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		out.Provide(act(i))
	}
}

// PipeAnyFunc returns a channel to receive every result of act applied to inp before close.
// Note: it 'could' be PipeAnyMap for functional people,
// but 'map' has a very different meaning in go lang.
func PipeAnyFunc(inp *AnyDemand, act func(a Any) Any) (out *AnyDemand) {
	cha := MakeAnyDemandChan()
	if act == nil {
		act = func(a Any) Any { return a }
	}
	go pipeAnyFunc(cha, inp, act)
	return cha
}

// End of PipeAny functions
// ===========================================================================
// ===========================================================================
// Beg of ForkAny functions

func forkAny(out1, out2 *AnyDemand, inp *AnyDemand) {
	defer out1.Close()
	defer out2.Close()
	for i, ok := inp.Request(); ok; i, ok = inp.Request() {
		out1.Provide(i)
		out2.Provide(i)
	}
}

// ForkAny returns two channels to receive every result of inp before close.
//  Note: Yes, it is a VERY simple fanout - but sometimes all You need.
func ForkAny(inp *AnyDemand) (out1, out2 *AnyDemand) {
	cha1 := MakeAnyDemandChan()
	cha2 := MakeAnyDemandChan()
	go forkAny(cha1, cha2, inp)
	return cha1, cha2
}

// End of ForkAny functions
// ===========================================================================
